// Gambar highlight (Destinasi Populer)
ScrollReveal().reveal('.highlight-logo', {
  duration: 1200,
  origin: 'bottom',
  distance: '30px',
  easing: 'ease-in-out',
  reset: false,
  mobile: true
});

ScrollReveal().reveal('.highlight-description p', {
  duration: 1200,
  origin: 'bottom',
  distance: '20px',
  delay: 200,
  easing: 'ease-in-out',
  reset: false,
  mobile: true
});

ScrollReveal().reveal('.card', {
  duration: 1000,
  origin: 'bottom',
  distance: '40px',
  interval: 100,
  easing: 'ease-in-out',
  reset: false,
  mobile: true
});

ScrollReveal().reveal('.button-all', {
  duration: 1000,
  origin: 'bottom',
  distance: '30px',
  delay: 300,
  easing: 'ease-in-out',
  reset: false,
  mobile: true
});

ScrollReveal().reveal('.animasi', {
  duration: 1000,
  origin: 'bottom',
  distance: '30px',
  interval: 200,
  easing: 'ease-in-out',
  reset: false,
  mobile: true
});

// Navigasi Scroll
const checkbox = document.getElementById('check');
  const body = document.body;

  checkbox.addEventListener('change', function () {
    if (this.checked) {
      body.classList.add('no-scroll');
    } else {
      body.classList.remove('no-scroll');
    }
  });

// Animasi teks muncul satu kali dari bawah ke atas
window.addEventListener('load', () => {
  const teksAnimasi = document.querySelectorAll('.animasi');
  teksAnimasi.forEach((el, index) => {
    setTimeout(() => {
      el.classList.add('show');
    }, 500 + index * 300); // delay antar elemen
  });
});

window.addEventListener('load', () => {
  const highlightText = document.querySelector('.highlight-description p');
  setTimeout(() => {
    highlightText.classList.add('show');
  }, 1000); // muncul setelah 1 detik
});