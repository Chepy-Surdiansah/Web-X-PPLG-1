const checkbox = document.getElementById('check');
  const body = document.body;

  checkbox.addEventListener('change', function () {
    if (this.checked) {
      body.classList.add('no-scroll');
    } else {
      body.classList.remove('no-scroll');
    }
  });
  
window.addEventListener('load', () => {
  const highlightText = document.querySelector('.highlight-description p');
  setTimeout(() => {
    highlightText.classList.add('show');
  }, 1200);
});

window.addEventListener('load', () => {
  const elemenAnimasi = document.querySelectorAll('.animasi');
  elemenAnimasi.forEach((el, i) => {
    setTimeout(() => {
      el.classList.add('show');
    }, 500 + i * 300); // muncul bergantian
  });
});

/* NAV */
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("menu-toggle");
  const navLinks = document.getElementById("nav-links");
  const backBtn = document.getElementById("back-button");

  toggle.addEventListener("click", () => {
    navLinks.classList.toggle("active");
    document.body.classList.toggle("no-scroll");
  });

  backBtn.addEventListener("click", () => {
    navLinks.classList.remove("active");
    document.body.classList.remove("no-scroll");
  });
});